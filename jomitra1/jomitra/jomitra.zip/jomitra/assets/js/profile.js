$(document).ready(function() {
  // mobile menu js
  // mobile menu js
  $('.bar').click (function(){
    $(this).toggleClass('open');
  });
  $('.bar').click (function(){
    $('nav.menu').toggleClass('show');
  });

  // show hide password
  // show hide password
  $(".toggle-password").click(function() {

    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
  });

  // notification
  // notification
  $(".doted, .exit").click(function(){
    $(".notification_box").fadeToggle(300);
    return false;
  });
  $(document).click(function(){
    $(".notification_box").hide();
  });
  $(".notification_box").click(function(){
    return false;
  });

  // slider
  // slider
  $('.slider_box').owlCarousel({
    loop:true,
    margin:20,
    dots:true,
    nav:false,
    responsive:{
      0:{
        items:1.1
      },
      576:{
        items:1.5
      },
      768:{
        items:2.5
      },
      1300:{
        items:4
      }
    }
  });
});


$(document).ready(function() {
  // Example starter JavaScript for disabling form submissions if there are invalid fields
  (() => {
    'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
    const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
    Array.from(forms).forEach(form => {
      form.addEventListener('submit', event => {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
  })()
});

$(document).ready(function() {
  if($(window).innerWidth() <= 991) {
    $(window).scroll(function(){
      if ($(this).scrollTop() > 1) {
        $('.side_bar').addClass('fixed');
      } else {
        $('.side_bar').removeClass('fixed');
      }
    });
  }
});


$(window).on('scroll',function(){
  let scroll = $(window).scrollTop();
  let oTop = $('.progress_bar').offset().top - window.innerHeight;
  if(scroll>oTop){
    $(".progress_bar").addClass("progressbar_active");
  }
  else{
    $(".progress_bar").removeClass("progressbar_active");
  }
});