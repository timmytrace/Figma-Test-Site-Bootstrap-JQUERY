
var hastag = document.getElementsById ("hashtags")
    hashtag.style.fontFamily= "Roboto";
    hashtag.style.size = "14px";
    hashtag.style.color = "rgba(0, 0, 0, 0.5)";